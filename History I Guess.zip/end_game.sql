CREATE PROCEDURE end_game(rid INT, secret_key CHAR(12))
COMMENT "it’s a secret don’t look"
BEGIN

END